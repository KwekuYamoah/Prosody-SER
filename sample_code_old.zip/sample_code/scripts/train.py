#!/usr/bin/env python3
"""
Memory-efficient training script following paper's approach with optimizations for 22GB GPU
Combines paper's methodology with memory management strategies
FIXED: Evaluation and test memory issues
"""

import os
import sys
import logging
import json
import gc
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Union, Any
import numpy as np
import torch
import torch.nn as nn
from transformers import (
    HfArgumentParser,
    AutoProcessor,
    AutoFeatureExtractor,
    set_seed,
    EvalPrediction
)
import datasets
from sklearn.metrics import accuracy_score, f1_score

# Import our optimized components
from sample_code.scripts.mtl_model import MTLModel
from sample_code.scripts.train_long import (
    MTLTrainer,
    MTLTrainingArguments,
    create_memory_efficient_trainer
)
from sample_code.scripts.mtl_dataset import DataCollatorMTL, MTLDataset

# Import existing components
from sample_code.scripts.backbone_models import BACKBONE_CONFIGS, BackboneModel
from sample_code.scripts.mtl_config import MTLConfig
from sample_code.scripts.tokenizer import SentencePieceTokenizer

# For ASR metrics
try:
    from jiwer import wer, cer
except ImportError:
    print("jiwer not installed. ASR metrics will not be available.")
    wer = cer = None

logger = logging.getLogger(__name__)


@dataclass
class ModelArguments:
    """Arguments for model configuration"""
    backbone_name: str = field(
        default="whisper",
        metadata={
            "help": "Backbone model name in [whisper, xlsr, mms, wav2vec2-bert]"}
    )
    vocab_size: int = field(
        default=16000,
        metadata={"help": "Vocabulary size for ASR"}
    )
    emotion_classes: int = field(
        default=9,
        metadata={"help": "Number of emotion classes"}
    )
    alpha_asr: float = field(
        default=0.1,
        metadata={"help": "Weight for ASR auxiliary task (following paper)"}
    )
    alpha_prosody: float = field(
        default=0.1,
        metadata={"help": "Weight for Prosody auxiliary task"}
    )
    freeze_feature_extractor: bool = field(
        default=True,
        metadata={
            "help": "Whether to freeze feature extractor (following paper)"}
    )
    cache_dir: Optional[str] = field(
        default=None,
        metadata={"help": "Cache directory for pretrained models"}
    )


@dataclass
class DataArguments:
    """Arguments for data configuration"""
    train_json: str = field(
        metadata={"help": "Path to training JSONL file"}
    )
    val_json: str = field(
        metadata={"help": "Path to validation JSONL file"}
    )
    audio_base_path: str = field(
        default="",
        metadata={"help": "Base path for audio files"}
    )
    test_json: Optional[str] = field(
        default=None,
        metadata={"help": "Path to test JSONL file"}
    )
    max_duration_in_seconds: Optional[float] = field(
        default=30.0,  # Reduced from 300s to save memory
        metadata={"help": "Maximum audio duration"}
    )
    preprocessing_num_workers: int = field(
        default=2,  # Reduced to save memory
        metadata={"help": "Number of workers for preprocessing"}
    )
    emotion_label_map: Optional[str] = field(
        default=None,
        metadata={"help": "JSON string mapping emotion names to indices"}
    )


def setup_memory_optimizations():
    """Setup global memory optimizations"""
    # Set memory fraction to leave room for other processes
    if torch.cuda.is_available():
        torch.cuda.set_per_process_memory_fraction(
            0.95)  # Use 95% of GPU memory

        # Enable memory optimizations
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.backends.cudnn.benchmark = True

        # Set CUDA memory allocation strategy
        os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:512,expandable_segments:True"

        print(
            f"GPU Memory Available: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
        print("Memory optimizations enabled")


def cleanup_memory():
    """Aggressive memory cleanup"""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()


def compute_metrics(eval_pred: EvalPrediction, tokenizer=None) -> Dict[str, float]:
    """
    Compute metrics for all tasks following paper's approach
    """
    predictions = eval_pred.predictions
    labels = eval_pred.label_ids

    metrics = {}

    # Unpack predictions and labels following paper's structure
    if len(predictions) == 3:
        ser_preds, asr_preds, prosody_preds = predictions
    else:
        logger.warning(
            f"Unexpected prediction format: {len(predictions)} elements")
        return metrics

    if isinstance(labels, tuple) and len(labels) == 3:
        asr_labels_info, ser_labels, prosody_labels = labels
        if isinstance(asr_labels_info, tuple):
            asr_labels, asr_lengths = asr_labels_info
        else:
            asr_labels = asr_labels_info
            asr_lengths = None
    else:
        logger.warning(f"Unexpected label format")
        return metrics

    # 1. SER metrics (main task following paper)
    if ser_preds is not None and ser_labels is not None:
        ser_predictions = np.argmax(ser_preds, axis=-1)
        ser_accuracy = accuracy_score(ser_labels, ser_predictions)
        ser_f1 = f1_score(ser_labels, ser_predictions, average='weighted')

        metrics['ser_accuracy'] = ser_accuracy
        metrics['ser_f1'] = ser_f1

    # 2. ASR metrics (auxiliary task following paper)
    if asr_preds is not None and asr_labels is not None and tokenizer is not None and wer is not None:
        asr_predictions = np.argmax(asr_preds, axis=-1)

        pred_texts = []
        ref_texts = []

        for i in range(len(asr_predictions)):
            # Decode prediction (simple greedy decoding following paper)
            pred_ids = asr_predictions[i]
            decoded_ids = []
            prev_id = -1
            for id in pred_ids:
                if id != 0 and id != prev_id:  # Remove blanks and repetitions
                    decoded_ids.append(id)
                prev_id = id

            pred_text = tokenizer.decode(decoded_ids, skip_special_tokens=True)
            pred_texts.append(pred_text)

            # Decode reference
            if asr_lengths is not None:
                ref_ids = asr_labels[i][:asr_lengths[i]] if i < len(
                    asr_lengths) else asr_labels[i]
            else:
                ref_ids = asr_labels[i]
            ref_ids = ref_ids[ref_ids != -100]
            ref_text = tokenizer.decode(
                ref_ids.tolist(), skip_special_tokens=True)
            ref_texts.append(ref_text)

        # Compute WER and CER
        word_error_rate = wer(ref_texts, pred_texts)
        char_error_rate = cer(ref_texts, pred_texts)

        metrics['asr_wer'] = word_error_rate
        metrics['asr_cer'] = char_error_rate

    # 3. Prosody metrics (sequence classification)
    if prosody_preds is not None and prosody_labels is not None:
        prosody_predictions = (prosody_preds > 0).astype(float).flatten()
        prosody_labels_flat = prosody_labels.flatten()

        # Remove padding
        mask = prosody_labels_flat >= 0
        if mask.sum() > 0:
            prosody_predictions_masked = prosody_predictions[mask]
            prosody_labels_masked = prosody_labels_flat[mask]

            prosody_accuracy = accuracy_score(
                prosody_labels_masked, prosody_predictions_masked)
            prosody_f1 = f1_score(prosody_labels_masked,
                                  prosody_predictions_masked, average='binary')

            metrics['prosody_accuracy'] = prosody_accuracy
            metrics['prosody_f1'] = prosody_f1

    return metrics


def load_preprocessed_datasets(data_args: DataArguments) -> Dict[str, List[Dict]]:
    """Load datasets from preprocessed JSONL files with memory optimization"""
    datasets_dict = {}

    def load_and_convert_jsonl(file_path):
        """Load JSONL and convert audio_data to numpy arrays"""
        data = []
        with open(file_path, 'r') as f:
            for line in f:
                item = json.loads(line)
                # Convert audio_data from list to numpy array efficiently
                if 'audio_data' in item and isinstance(item['audio_data'], list):
                    item['audio_data'] = np.array(
                        item['audio_data'], dtype=np.float32)
                data.append(item)
        return data

    # Load training data
    print(f"Loading preprocessed training data from {data_args.train_json}")
    datasets_dict['train'] = load_and_convert_jsonl(data_args.train_json)

    # Load validation data
    print(f"Loading preprocessed validation data from {data_args.val_json}")
    datasets_dict['validation'] = load_and_convert_jsonl(data_args.val_json)

    # Load test data if provided
    if data_args.test_json:
        print(f"Loading preprocessed test data from {data_args.test_json}")
        datasets_dict['test'] = load_and_convert_jsonl(data_args.test_json)

    return datasets_dict


class MemoryEfficientMTLTrainer(MTLTrainer):
    """Enhanced MTL Trainer with better memory management for evaluation"""
    
    def evaluation_loop(
        self,
        dataloader,
        description,
        prediction_loss_only=None,
        ignore_keys=None,
        metric_key_prefix="eval",
    ):
        """
        Override evaluation loop with memory optimizations
        """
        # Force smaller eval batch size if needed
        if len(dataloader) > 0:
            # Get the actual batch size from dataloader
            actual_batch_size = dataloader.batch_size
            if actual_batch_size > 1:
                print(f"Warning: Eval batch size {actual_batch_size} might cause OOM. Consider reducing to 1.")
        
        # Enable memory efficient mode
        self.model.eval()
        
        # Clear memory before evaluation
        cleanup_memory()
        
        # Call parent evaluation loop with memory cleanup between batches
        try:
            # Store original prediction step
            original_prediction_step = self.prediction_step
            
            # Create wrapper with memory cleanup
            def prediction_step_with_cleanup(*args, **kwargs):
                result = original_prediction_step(*args, **kwargs)
                # Cleanup every few batches
                if hasattr(self, '_eval_step_count'):
                    self._eval_step_count += 1
                else:
                    self._eval_step_count = 1
                
                if self._eval_step_count % 10 == 0:  # Cleanup every 10 batches
                    cleanup_memory()
                
                return result
            
            # Temporarily replace prediction step
            self.prediction_step = prediction_step_with_cleanup
            self._eval_step_count = 0
            
            # Run evaluation
            result = super().evaluation_loop(
                dataloader,
                description,
                prediction_loss_only,
                ignore_keys,
                metric_key_prefix,
            )
            
            # Restore original prediction step
            self.prediction_step = original_prediction_step
            del self._eval_step_count
            
            # Final cleanup
            cleanup_memory()
            
            return result
            
        except RuntimeError as e:
            if "out of memory" in str(e):
                print("\n❌ GPU Out of Memory during evaluation!")
                print("Attempting to recover...")
                cleanup_memory()
                raise e
            else:
                raise e


def main():
    # Parse arguments
    parser = HfArgumentParser((ModelArguments, DataArguments))

    if len(sys.argv) == 2 and sys.argv[1].endswith(".json"):
        model_args, data_args = parser.parse_json_file(
            json_file=os.path.abspath(sys.argv[1]))
    else:
        model_args, data_args = parser.parse_args_into_dataclasses()

    # Setup logging
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
        level=logging.INFO
    )

    print("\n" + "="*60)
    print("🚀 MEMORY-EFFICIENT MTL TRAINING")
    print("Following paper's approach with 22GB GPU optimizations")
    print("="*60)

    # Setup memory optimizations
    setup_memory_optimizations()

    # Set seed
    set_seed(42)
    print(f"🎲 Set random seed to 42")

    # Load datasets
    print("\n📊 Loading datasets...")
    datasets_dict = load_preprocessed_datasets(data_args)
    print(f"   ✓ Training: {len(datasets_dict['train'])} samples")
    print(f"   ✓ Validation: {len(datasets_dict['validation'])} samples")

    # Load processor following paper's approach
    print("\n🔧 Loading processor...")
    try:
        processor = AutoProcessor.from_pretrained(
            BACKBONE_CONFIGS[model_args.backbone_name].pretrained_model_name,
            cache_dir=model_args.cache_dir
        )
    except:
        processor = AutoFeatureExtractor.from_pretrained(
            BACKBONE_CONFIGS[model_args.backbone_name].pretrained_model_name,
            cache_dir=model_args.cache_dir
        )

    # Setup tokenizer
    print("🔤 Setting up tokenizer...")
    tokenizer_dir = f"./tokenizer_{model_args.backbone_name}"
    tokenizer_file = os.path.join(tokenizer_dir, "spm.model")

    if os.path.exists(tokenizer_file):
        print(f"   Loading existing tokenizer from {tokenizer_file}")
        tokenizer = SentencePieceTokenizer(model_path=tokenizer_file)
        tokenizer.load_tokenizer()
    else:
        print("   Creating new tokenizer")
        # Extract texts for tokenizer training
        all_texts = []
        for split in datasets_dict:
            for item in datasets_dict[split]:
                if 'words' in item:
                    all_texts.append(" ".join(item['words']))

        # Train tokenizer
        os.makedirs(tokenizer_dir, exist_ok=True)
        text_file = os.path.join(tokenizer_dir, "training_text.txt")
        with open(text_file, 'w') as f:
            for text in all_texts:
                f.write(text + '\n')

        tokenizer = SentencePieceTokenizer(vocab_size=model_args.vocab_size)
        tokenizer.train_tokenizer(
            text_file, model_prefix=os.path.join(tokenizer_dir, "spm"))

    print(f"   Tokenizer vocabulary size: {tokenizer.get_vocab_size()}")

    # Parse emotion label map
    emotion_label_map = None
    if data_args.emotion_label_map:
        emotion_label_map = json.loads(data_args.emotion_label_map)

    # Create feature extractor
    print("\n⚙️ Creating feature extractor...")
    temp_backbone = BackboneModel(BACKBONE_CONFIGS[model_args.backbone_name])
    feature_extractor = temp_backbone.feature_extractor
    del temp_backbone
    cleanup_memory()

    # Create model configuration following paper
    print("🔧 Creating model configuration...")
    config = MTLConfig(
        backbone_name=model_args.backbone_name,
        vocab_size=tokenizer.get_vocab_size(),
        emotion_classes=model_args.emotion_classes,
        alpha_asr=model_args.alpha_asr,
        alpha_prosody=model_args.alpha_prosody,
        freeze_encoder=model_args.freeze_feature_extractor
    )

    print(f"   SER (main task): weight = 1.0")
    print(f"   ASR (auxiliary): alpha = {model_args.alpha_asr}")
    print(f"   Prosody (auxiliary): alpha = {model_args.alpha_prosody}")

    # Create memory-efficient model
    print("\n🤖 Creating memory-efficient model...")
    model = MTLModel(config)

    if model_args.freeze_feature_extractor:
        model.freeze_feature_extractor()
        print("   ✓ Feature extractor frozen")

    # Move model to GPU with memory optimization
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    # Print model statistics
    trainable_params = model.num_parameters(only_trainable=True)
    total_params = model.num_parameters(only_trainable=False)
    model_memory = model.get_memory_footprint()

    print(f"\n📊 Model Statistics:")
    print(f"   Trainable parameters: {trainable_params:,}")
    print(f"   Total parameters: {total_params:,}")
    print(f"   Model memory: {model_memory:.2f} MB")
    print(
        f"   GPU memory after model loading: {torch.cuda.memory_allocated() / 1e9:.2f} GB")

    # Create memory-efficient datasets
    print("\n📝 Creating memory-efficient datasets...")

    # Calculate max audio length based on available memory
    max_audio_length = int(
        data_args.max_duration_in_seconds * 16000)  # 30s * 16kHz

    train_dataset = MTLDataset(
        datasets_dict['train'],
        config=config,
        feature_extractor=feature_extractor,
        emotion_label_map=emotion_label_map,
        max_audio_length=max_audio_length
    )

    val_dataset = MTLDataset(
        datasets_dict['validation'],
        config=config,
        feature_extractor=feature_extractor,
        emotion_label_map=emotion_label_map,
        max_audio_length=max_audio_length
    )

    print(f"   ✓ Training dataset: {len(train_dataset)} samples")
    print(f"   ✓ Validation dataset: {len(val_dataset)} samples")

    # Create memory-efficient data collator
    print("\n🔄 Creating memory-efficient data collator...")
    data_collator = DataCollatorMTL(
        processor=processor,
        tokenizer=tokenizer,
        padding=True,
        return_attention_mask=True,
        pad_to_multiple_of=8  # For memory efficiency
    )

    # Create memory-optimized training arguments
    print("\n⚙️ Creating training configuration...")
    training_args = MTLTrainingArguments.create_for_22gb_gpu(
        output_dir=f"./checkpoints_{model_args.backbone_name}",
        num_train_epochs=1,
        # Following paper's approach
        learning_rate=5e-5 if model_args.alpha_asr > 0 else 1e-5,
        per_device_train_batch_size=1,  # Small batch for memory
        per_device_eval_batch_size=1,   # CRITICAL: Keep eval batch size at 1
        gradient_accumulation_steps=2,   # Simulate batch size of 2
        warmup_ratio=0.1,
        save_strategy="epoch",
        evaluation_strategy="epoch",
        logging_steps=100,
        dataloader_num_workers=0,  # Avoid multiprocessing memory issues
        remove_unused_columns=False,
        fp16=True,
        gradient_checkpointing=True,
        # eval_accumulation_steps=4,  # Accumulate eval results to save memory
    )

    print(
        f"   ✓ Effective batch size: {training_args.per_device_train_batch_size * training_args.gradient_accumulation_steps}")
    print(f"   ✓ Learning rate: {training_args.learning_rate}")
    print(f"   ✓ Mixed precision: {training_args.fp16}")
    print(
        f"   ✓ Gradient checkpointing: {training_args.gradient_checkpointing}")

    # Create memory-efficient trainer with enhanced evaluation
    print("\n🎯 Creating memory-efficient trainer...")
    trainer = MemoryEfficientMTLTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        tokenizer=processor,
        data_collator=data_collator,
        compute_metrics=lambda eval_pred: compute_metrics(
            eval_pred, tokenizer),
        use_amp=True,
        gradient_accumulation_steps=training_args.gradient_accumulation_steps,
    )

    print(f"   ✓ Trainer created with AMP and gradient accumulation")

    # Training
    print("\n" + "="*60)
    print("🚂 Starting memory-efficient training...")
    print("="*60)

    # Clear memory before training
    cleanup_memory()

    try:
        # Train the model
        train_result = trainer.train()

        # Save model
        trainer.save_model()

        # Save metrics
        metrics = train_result.metrics
        trainer.log_metrics("train", metrics)
        trainer.save_metrics("train", metrics)
        trainer.save_state()

        print("\n" + "="*60)
        print("✅ Training completed successfully!")
        print("="*60)
        print("\n📊 Final Training Metrics:")
        for key, value in metrics.items():
            print(f"   {key}: {value:.4f}")

        # Final memory stats
        print(
            f"\n💾 Final GPU memory usage: {torch.cuda.memory_allocated() / 1e9:.2f} GB")

    except RuntimeError as e:
        if "out of memory" in str(e):
            print("\n❌ GPU Out of Memory Error!")
            print("Suggestions:")
            print("  1. Reduce batch size further (try per_device_train_batch_size=1)")
            print("  2. Increase gradient_accumulation_steps")
            print("  3. Reduce max_duration_in_seconds")
            print("  4. Use smaller backbone model")
            print(f"\nError details: {e}")
        else:
            raise e

    # Evaluation
    try:
        print("\n📊 Starting evaluation...")
        cleanup_memory()

        # Force model to evaluation mode
        model.eval()
        
        # Run evaluation with smaller batch size
        metrics = trainer.evaluate()
        trainer.log_metrics("eval", metrics)
        trainer.save_metrics("eval", metrics)

        print("\n✅ Evaluation completed!")
        print("\n📊 Evaluation Metrics:")
        for key, value in metrics.items():
            print(f"   {key}: {value:.4f}")

    except Exception as e:
        print(f"⚠️ Evaluation failed: {e}")
        if "out of memory" in str(e):
            print("\nTrying evaluation with batch size 1...")
            # Force batch size 1 for evaluation
            trainer.args.per_device_eval_batch_size = 1
            trainer.args.eval_accumulation_steps = 8
            try:
                cleanup_memory()
                metrics = trainer.evaluate()
                print("\n✅ Evaluation completed with reduced batch size!")
                print("\n📊 Evaluation Metrics:")
                for key, value in metrics.items():
                    print(f"   {key}: {value:.4f}")
            except Exception as e2:
                print(f"⚠️ Evaluation still failed: {e2}")

    # Test evaluation if test data provided
    if data_args.test_json:
        try:
            print("\n🧪 Starting test evaluation...")
            cleanup_memory()

            test_dataset = MTLDataset(
                datasets_dict['test'],
                config=config,
                feature_extractor=feature_extractor,
                emotion_label_map=emotion_label_map,
                max_audio_length=max_audio_length
            )

            # Force batch size 1 for test evaluation
            trainer.args.per_device_eval_batch_size = 1
            trainer.args.eval_accumulation_steps = 8
            
            predictions, labels, metrics = trainer.predict(
                test_dataset, metric_key_prefix="test")
            trainer.log_metrics("test", metrics)
            trainer.save_metrics("test", metrics)

            print("\n✅ Test evaluation completed!")
            print("\n📊 Test Metrics:")
            for key, value in metrics.items():
                print(f"   {key}: {value:.4f}")

        except Exception as e:
            print(f"⚠️ Test evaluation failed: {e}")

    print("\n" + "="*60)
    print("🎉 Pipeline completed!")
    print("="*60)

    # Final cleanup
    cleanup_memory()


if __name__ == "__main__":
    main()