import torch
import torch.nn as nn
try:
    # Use new autocast import for newer PyTorch versions
    from torch.amp import autocast
except ImportError:
    # Fallback for older PyTorch versions
    from torch.cuda.amp import autocast

from torch.cuda.amp import GradScaler
from transformers import Trainer
from transformers.trainer_utils import get_last_checkpoint
from typing import Dict, Union, Any, Optional
import os


class MTLTrainer(Trainer):
    """
    Memory-efficient custom trainer following paper's approach with optimizations for 22GB GPU
    """

    def __init__(self, *args, use_amp: bool = True, gradient_accumulation_steps: int = 4, **kwargs):
        super().__init__(*args, **kwargs)

        # Memory optimization settings
        self.use_amp = use_amp
        # Remove manual scaler - let Transformers handle it
        self.gradient_accumulation_steps = gradient_accumulation_steps

        # Check if model supports gradient checkpointing
        self.supports_gradient_checkpointing = self._check_gradient_checkpointing_support()

        # Enable memory optimizations
        self._setup_memory_optimizations()

        print(f"MTLTrainer initialized with:")
        print(f"  - AMP enabled: {self.use_amp}")
        print(
            f"  - Gradient accumulation steps: {self.gradient_accumulation_steps}")
        print(
            f"  - Gradient checkpointing supported: {self.supports_gradient_checkpointing}")

        # Safe memory footprint check
        try:
            if hasattr(self.model, 'get_memory_footprint'):
                print(
                    f"  - Model memory: {self.model.get_memory_footprint():.2f} MB")
        except Exception as e:
            print(f"  - Could not get model memory footprint: {e}")

    def _check_gradient_checkpointing_support(self) -> bool:
        """Check if the model supports gradient checkpointing"""
        try:
            # Try to enable gradient checkpointing
            if hasattr(self.model, 'gradient_checkpointing_enable'):
                self.model.gradient_checkpointing_enable()
                return True
            elif hasattr(self.model, '_enable_gradient_checkpointing'):
                self.model._enable_gradient_checkpointing()
                return True
            return False
        except Exception:
            return False

    def _setup_memory_optimizations(self):
        """Setup memory optimizations following paper's approach"""
        # Enable torch optimizations
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    def _prepare_inputs(self, inputs: Dict[str, Union[torch.Tensor, Any]]) -> Dict[str, Union[torch.Tensor, Any]]:
        """
        Prepare inputs with special handling for multi-task labels following paper's approach
        """
        for k, v in inputs.items():
            if isinstance(v, torch.Tensor):
                kwargs = dict(device=self.args.device, non_blocking=True)
                if self.use_amp and v.dtype == torch.float32:
                    kwargs.update(dict(dtype=torch.float16))
                inputs[k] = v.to(**kwargs)

            # Special handling for labels tuple (CTC labels, SER labels, Prosody labels)
            elif k == 'labels' and isinstance(v, (tuple, list)):
                processed_labels = []
                for i, label_component in enumerate(v):
                    if label_component is not None:
                        if isinstance(label_component, (tuple, list)):
                            # Handle nested tuples (e.g., ASR labels with lengths)
                            processed_component = []
                            for sub_item in label_component:
                                if isinstance(sub_item, torch.Tensor):
                                    kwargs = dict(
                                        device=self.args.device, non_blocking=True)
                                    processed_component.append(
                                        sub_item.to(**kwargs))
                                else:
                                    processed_component.append(sub_item)
                            processed_labels.append(tuple(processed_component))
                        elif isinstance(label_component, torch.Tensor):
                            kwargs = dict(device=self.args.device,
                                          non_blocking=True)
                            processed_labels.append(
                                label_component.to(**kwargs))
                        else:
                            processed_labels.append(label_component)
                    else:
                        processed_labels.append(None)
                inputs[k] = tuple(processed_labels)

        return inputs

    def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
        """
        Compute multi-task loss with memory optimizations following paper's approach
        """
        # Prepare inputs
        inputs = self._prepare_inputs(inputs)

        # Forward pass with mixed precision using new autocast API
        if self.use_amp:
            device_type = 'cuda' if torch.cuda.is_available() else 'cpu'
            with autocast(device_type=device_type):
                outputs = model(**inputs)
                loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]
        else:
            outputs = model(**inputs)
            loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]

        # Scale loss for gradient accumulation
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps

        return (loss, outputs) if return_outputs else loss

    def training_step(
        self,
        model: nn.Module,
        inputs: Dict[str, Union[torch.Tensor, Any]],
        num_items_in_batch: Optional[int] = None
    ) -> torch.Tensor:
        """
        Perform a training step with memory optimizations following paper's approach
        Let Transformers handle the backward pass and scaling
        """
        model.train()

        # Use parent's training_step to ensure proper integration with Transformers
        # This handles AMP scaling properly
        return super().training_step(model, inputs, num_items_in_batch)

    def _maybe_log_save_evaluate(self, tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, start_time=None, **kwargs):
        """Override to handle memory cleanup"""
        # Clear cache before evaluation
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return super()._maybe_log_save_evaluate(tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, start_time, **kwargs)

    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        """
        Custom prediction step with memory optimizations and multi-task handling
        """
        # Get label names safely
        label_names = getattr(self, 'label_names', ['labels'])
        has_labels = any(inputs.get(k) is not None for k in label_names)
        inputs = self._prepare_inputs(inputs)

        with torch.no_grad():
            if self.use_amp:
                device_type = 'cuda' if torch.cuda.is_available() else 'cpu'
                with autocast(device_type=device_type):
                    outputs = model(**inputs)
            else:
                outputs = model(**inputs)

            if has_labels:
                loss = outputs.loss if hasattr(outputs, 'loss') else outputs[0]
            else:
                loss = None

            # Extract logits for each task
            if hasattr(outputs, 'ser_logits'):
                ser_logits = outputs.ser_logits
                asr_logits = outputs.asr_logits
                prosody_logits = outputs.prosody_logits
                logits = (ser_logits, asr_logits, prosody_logits)
            else:
                # Fallback for tuple outputs
                logits = outputs[1:4] if len(outputs) > 3 else outputs[1:]

        if prediction_loss_only:
            return (loss, None, None)

        # Get labels
        labels = inputs.get("labels", None)
        return (loss, logits, labels)

    def train(self, resume_from_checkpoint: Optional[str] = None, **kwargs):
        """
        Enhanced train method with memory monitoring and dynamic gradient checkpointing
        """
        # Print initial memory stats
        if torch.cuda.is_available():
            try:
                print(
                    f"GPU memory before training: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
            except Exception as e:
                print(f"Could not get GPU memory stats: {e}")

        # Temporarily disable gradient checkpointing in args if not supported
        original_gradient_checkpointing = self.args.gradient_checkpointing
        if not self.supports_gradient_checkpointing:
            self.args.gradient_checkpointing = False

        try:
            # Call parent train method - let it handle AMP properly
            result = super().train(resume_from_checkpoint=resume_from_checkpoint, **kwargs)
        finally:
            # Restore original gradient checkpointing setting
            self.args.gradient_checkpointing = original_gradient_checkpointing

        # Print final memory stats
        if torch.cuda.is_available():
            try:
                print(
                    f"GPU memory after training: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
            except Exception as e:
                print(f"Could not get final GPU memory stats: {e}")

        return result

    def create_optimizer_and_scheduler(self, num_training_steps: int):
        """Create optimizer and scheduler with memory optimizations"""
        super().create_optimizer_and_scheduler(num_training_steps)
        # Remove manual scaler setup - Transformers handles this

    def _save_checkpoint(self, model, trial, metrics=None):
        """Save checkpoint with memory cleanup"""
        # Clear cache before saving
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        super()._save_checkpoint(model, trial, metrics)

    def evaluate(self, eval_dataset=None, ignore_keys=None, metric_key_prefix: str = "eval"):
        """Evaluate with memory optimizations"""
        # Clear cache before evaluation
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return super().evaluate(eval_dataset, ignore_keys, metric_key_prefix)


def create_memory_efficient_trainer(
    model,
    args,
    train_dataset=None,
    eval_dataset=None,
    tokenizer=None,
    data_collator=None,
    compute_metrics=None,
    use_amp: bool = True,
    gradient_accumulation_steps: int = 4,
):
    """
    Factory function to create memory-efficient trainer with paper's optimizations
    """

    # Apply model optimizations safely
    print("\n🔧 Applying memory optimizations...")

    # Try gradient checkpointing if supported
    try:
        if hasattr(model, 'gradient_checkpointing_enable'):
            model.gradient_checkpointing_enable()
            print("  ✓ Gradient checkpointing enabled")
        elif hasattr(model, '_enable_gradient_checkpointing'):
            model._enable_gradient_checkpointing()
            print("  ✓ Legacy gradient checkpointing enabled")
        else:
            print("  ⚠️ Gradient checkpointing not supported by model")
    except Exception as e:
        print(f"  ⚠️ Could not enable gradient checkpointing: {e}")

    # Apply other memory optimizations
    try:
        # Enable memory-efficient attention if available
        if hasattr(model, 'enable_memory_efficient_attention'):
            model.enable_memory_efficient_attention()
            print("  ✓ Memory-efficient attention enabled")
    except Exception as e:
        print(f"  ⚠️ Could not enable memory-efficient attention: {e}")

    try:
        # Enable flash attention if available
        if hasattr(model, 'enable_flash_attention'):
            model.enable_flash_attention()
            print("  ✓ Flash attention enabled")
    except Exception as e:
        print(f"  ⚠️ Could not enable flash attention: {e}")

    # Create trainer with memory optimizations
    trainer = MTLTrainer(
        model=model,
        args=args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
        use_amp=use_amp,
        gradient_accumulation_steps=gradient_accumulation_steps,
    )

    return trainer


class MTLTrainingArguments:
    """
    Helper class to create memory-optimized training arguments
    """

    @staticmethod
    def create_for_22gb_gpu(
        output_dir: str,
        num_train_epochs: int = 1,
        learning_rate: float = 5e-5,
        per_device_train_batch_size: int = 1,  # Small batch size for memory
        per_device_eval_batch_size: int = 1,
        gradient_accumulation_steps: int = 2,  # Simulate larger batch size
        warmup_ratio: float = 0.1,
        save_strategy: str = "epoch",
        evaluation_strategy: str = "epoch",
        logging_steps: int = 10,
        **kwargs
    ):
        """
        Create training arguments optimized for 22GB GPU following paper's approach
        """
        from transformers import TrainingArguments
        import transformers

        # Define parameters that we want to control explicitly
        # Remove them from kwargs to avoid conflicts
        explicit_params = {
            'dataloader_num_workers',
            'remove_unused_columns',
            'dataloader_pin_memory',
            'fp16',
            'gradient_checkpointing',
            'report_to',
            'save_total_limit',
            'load_best_model_at_end',
            'metric_for_best_model',
            'greater_is_better',
            'weight_decay'
        }

        # Create a clean kwargs dict without conflicting parameters
        clean_kwargs = {k: v for k,
                        v in kwargs.items() if k not in explicit_params}

        # Check transformers version to handle evaluation_strategy vs eval_strategy
        # In newer versions, it's eval_strategy
        transformers_version = tuple(
            int(x) for x in transformers.__version__.split('.')[:2])
        eval_strategy_key = 'eval_strategy' if transformers_version >= (
            4, 20) else 'evaluation_strategy'

        # Create base arguments
        base_args = {
            'output_dir': output_dir,
            'num_train_epochs': num_train_epochs,
            'learning_rate': learning_rate,
            'per_device_train_batch_size': per_device_train_batch_size,
            'per_device_eval_batch_size': per_device_eval_batch_size,
            'gradient_accumulation_steps': gradient_accumulation_steps,
            'warmup_ratio': warmup_ratio,
            'weight_decay': kwargs.get('weight_decay', 0.01),
            'logging_steps': logging_steps,
            'save_strategy': save_strategy,
            eval_strategy_key: evaluation_strategy,  # Use the correct key based on version
            # Limit saved checkpoints
            'save_total_limit': kwargs.get('save_total_limit', 2),
            'load_best_model_at_end': kwargs.get('load_best_model_at_end', True),
            'metric_for_best_model': kwargs.get('metric_for_best_model', "eval_loss"),
            'greater_is_better': kwargs.get('greater_is_better', False),
            # Disable wandb/tensorboard to save memory
            'report_to': kwargs.get('report_to', None),
            # Disable pin memory to save GPU memory
            'dataloader_pin_memory': kwargs.get('dataloader_pin_memory', False),
            # Single-threaded to avoid memory issues
            'dataloader_num_workers': kwargs.get('dataloader_num_workers', 0),
            # Keep all columns for multi-task
            'remove_unused_columns': kwargs.get('remove_unused_columns', False),
            'fp16': kwargs.get('fp16', True),  # Enable mixed precision
            # Enable gradient checkpointing
            'gradient_checkpointing': kwargs.get('gradient_checkpointing', True),
        }

        # Merge with clean kwargs
        base_args.update(clean_kwargs)

        try:
            return TrainingArguments(**base_args)
        except Exception as e:
            print(f"Error creating TrainingArguments: {e}")
            print(f"Attempting with alternative parameter names...")

            # Try both eval_strategy and evaluation_strategy
            if 'eval_strategy' in str(e) or 'evaluation_strategy' in str(e):
                # Try the opposite key
                alt_eval_key = 'evaluation_strategy' if eval_strategy_key == 'eval_strategy' else 'eval_strategy'
                base_args[alt_eval_key] = base_args.pop(eval_strategy_key)
                try:
                    return TrainingArguments(**base_args)
                except Exception as e2:
                    print(f"Still getting error: {e2}")
                    # Remove evaluation strategy altogether as last resort
                    base_args.pop(alt_eval_key, None)
                    base_args.pop('eval_strategy', None)
                    base_args.pop('evaluation_strategy', None)
                    print("Removing evaluation strategy parameter entirely...")

            # Try with minimal arguments if there's still an issue
            minimal_args = {
                'output_dir': output_dir,
                'num_train_epochs': num_train_epochs,
                'learning_rate': learning_rate,
                'per_device_train_batch_size': per_device_train_batch_size,
                'per_device_eval_batch_size': per_device_eval_batch_size,
                'gradient_accumulation_steps': gradient_accumulation_steps,
                'warmup_ratio': warmup_ratio,
                'logging_steps': logging_steps,
                'save_strategy': save_strategy,
            }

            # Try adding evaluation strategy with both possible keys
            for eval_key in ['eval_strategy', 'evaluation_strategy']:
                try:
                    minimal_args[eval_key] = evaluation_strategy
                    return TrainingArguments(**minimal_args)
                except:
                    minimal_args.pop(eval_key, None)
                    continue

            # If all else fails, return without evaluation strategy
            print("Warning: Could not set evaluation strategy. Training will proceed without automatic evaluation.")
            return TrainingArguments(**minimal_args)