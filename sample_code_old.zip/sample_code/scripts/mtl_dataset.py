import torch
from torch.utils.data import Dataset
from typing import Dict, List, Optional, Union, Any
import numpy as np
from transformers import AutoProcessor, AutoFeatureExtractor
from dataclasses import dataclass
import gc


@dataclass
class DataCollatorMTL:
    """
    Memory-efficient data collator for multi-task learning following paper's approach.
    Optimized for 22GB GPU with batch processing and memory management.
    """

    processor: Union[AutoProcessor, AutoFeatureExtractor]
    tokenizer: Optional[Any] = None
    padding: Union[bool, str] = True
    max_length: Optional[int] = None
    pad_to_multiple_of: Optional[int] = None
    return_attention_mask: bool = True
    audio_only: bool = False  # Following paper's approach for inference

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """
        Collate batch with memory optimizations following paper's approach
        """
        # Prepare batch dictionary
        batch = {}
        
        # Process input features with memory efficiency
        batch = self._process_input_features(features, batch)
        
        # Process labels for multi-task learning (following paper's approach)
        if not self.audio_only:
            batch = self._process_labels(features, batch)
        
        return batch

    def _process_input_features(self, features: List[Dict[str, Any]], batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Process input features with memory optimization"""
        # Extract input features 
        input_features_list = [feature["input_features"] for feature in features]
        
        # Determine feature type and pad efficiently
        if len(input_features_list[0].shape) == 2:
            # 2D features (mel-spectrogram for Whisper)
            batch = self._pad_2d_features(input_features_list, batch)
        elif len(input_features_list[0].shape) == 1:
            # 1D features (waveform for wav2vec2)
            batch = self._pad_1d_features(input_features_list, batch)
        else:
            raise ValueError(f"Unexpected feature shape: {input_features_list[0].shape}")
        
        return batch

    def _pad_2d_features(self, input_features_list: List[torch.Tensor], batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Pad 2D features (mel-spectrograms) efficiently"""
        # Find max dimensions
        max_freq = max(feat.shape[0] for feat in input_features_list)
        max_time = max(feat.shape[1] for feat in input_features_list)
        
        # Apply pad_to_multiple_of if specified (for memory efficiency)
        if self.pad_to_multiple_of is not None:
            max_time = ((max_time + self.pad_to_multiple_of - 1) // 
                       self.pad_to_multiple_of) * self.pad_to_multiple_of
        
        batch_size = len(input_features_list)
        
        # Create padded tensor with memory-efficient dtype
        padded_features = torch.zeros(
            batch_size, max_freq, max_time, 
            dtype=torch.float16  # Use half precision to save memory
        )
        
        # Create attention mask if needed
        attention_mask = None
        if self.return_attention_mask:
            attention_mask = torch.zeros(batch_size, max_time, dtype=torch.bool)
        
        # Fill with actual features
        for i, feat in enumerate(input_features_list):
            freq_dim, time_dim = feat.shape
            padded_features[i, :freq_dim, :time_dim] = feat.half()
            if attention_mask is not None:
                attention_mask[i, :time_dim] = True
        
        batch["input_features"] = padded_features
        if attention_mask is not None:
            batch["attention_mask"] = attention_mask
        
        return batch

    def _pad_1d_features(self, input_features_list: List[torch.Tensor], batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Pad 1D features (waveforms) efficiently"""
        # Find max length
        max_length = max(feat.shape[0] for feat in input_features_list)
        
        # Apply pad_to_multiple_of if specified
        if self.pad_to_multiple_of is not None:
            max_length = ((max_length + self.pad_to_multiple_of - 1) // 
                         self.pad_to_multiple_of) * self.pad_to_multiple_of
        
        batch_size = len(input_features_list)
        
        # Create padded tensor with memory-efficient dtype
        padded_features = torch.zeros(
            batch_size, max_length,
            dtype=torch.float16  # Use half precision
        )
        
        # Create attention mask
        attention_mask = None
        if self.return_attention_mask:
            attention_mask = torch.ones(batch_size, max_length, dtype=torch.bool)
        
        # Fill with actual features
        for i, feat in enumerate(input_features_list):
            length = feat.shape[0]
            padded_features[i, :length] = feat.half()
            if attention_mask is not None:
                attention_mask[i, length:] = False
        
        batch["input_values"] = padded_features
        if attention_mask is not None:
            batch["attention_mask"] = attention_mask
        
        return batch

    def _process_labels(self, features: List[Dict[str, Any]], batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Process labels for multi-task learning following paper's approach
        Paper uses: (CTC labels, emotion labels) - we extend to: (CTC labels, emotion labels, prosody labels)
        """
        # 1. Process ASR labels (CTC) following paper's approach
        asr_labels, asr_lengths = self._process_asr_labels(features)
        
        # 2. Process SER labels (emotion classification) following paper's approach  
        emotion_labels = self._process_emotion_labels(features)
        
        # 3. Process Prosody labels (sequence labeling) - our extension
        prosody_labels = self._process_prosody_labels(features, batch)
        
        # Combine labels into tuple following paper's structure
        if asr_labels is not None:
            batch["labels"] = ((asr_labels, asr_lengths), emotion_labels, prosody_labels)
        else:
            batch["labels"] = (None, emotion_labels, prosody_labels)
        
        return batch

    def _process_asr_labels(self, features: List[Dict[str, Any]]) -> tuple:
        """Process ASR labels following paper's CTC approach"""
        if self.tokenizer is None:
            return None, None
        
        # Get text from features
        texts = []
        for feature in features:
            words = feature.get("asr_target", feature.get("words", []))
            text = " ".join(words) if isinstance(words, list) else str(words)
            texts.append(text)
        
        if not texts or all(not text.strip() for text in texts):
            return None, None
        
        # Tokenize texts efficiently
        tokenized = []
        for text in texts:
            if hasattr(self.tokenizer, 'encode'):
                token_ids = self.tokenizer.encode(text, add_special_tokens=True)
            else:
                # Fallback for different tokenizer interfaces
                token_ids = self.tokenizer(text)["input_ids"]
            tokenized.append(torch.tensor(token_ids, dtype=torch.long))
        
        # Pad sequences following paper's approach
        if tokenized:
            asr_labels = torch.nn.utils.rnn.pad_sequence(
                tokenized, batch_first=True, padding_value=-100
            )
            asr_lengths = torch.tensor([len(t) for t in tokenized], dtype=torch.long)
        else:
            asr_labels = None
            asr_lengths = None
        
        return asr_labels, asr_lengths

    def _process_emotion_labels(self, features: List[Dict[str, Any]]) -> torch.Tensor:
        """Process emotion labels following paper's approach"""
        emotion_labels = torch.tensor(
            [feature.get("emotion_targets", 0) for feature in features],
            dtype=torch.long
        )
        return emotion_labels

    def _process_prosody_labels(self, features: List[Dict[str, Any]], batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Process prosody labels for sequence classification"""
        prosody_sequences = []
        
        # Determine target length from input features
        if "input_values" in batch:
            # For wav2vec2-like models
            target_len = batch["input_values"].shape[1] // 320  # Approximate frame reduction
        else:
            # For whisper-like models  
            target_len = batch["input_features"].shape[-1]
        
        for feature in features:
            # Get prosody targets
            prosody = feature.get("prosody_targets", [])
            
            # Ensure it's a tensor
            if not isinstance(prosody, torch.Tensor):
                if isinstance(prosody, (list, np.ndarray)):
                    prosody = torch.tensor(prosody, dtype=torch.float32)
                else:
                    prosody = torch.tensor([prosody], dtype=torch.float32)
            
            # Adjust to target length
            if len(prosody) == 0:
                # No prosody labels, create zeros
                prosody_tensor = torch.zeros(target_len, dtype=torch.float32)
            elif len(prosody) != target_len:
                # Interpolate to match target length
                if len(prosody) > 1:
                    indices = torch.linspace(0, len(prosody) - 1, target_len).long()
                    indices = torch.clamp(indices, 0, len(prosody) - 1)
                    prosody_tensor = prosody[indices]
                else:
                    # Single value, repeat
                    prosody_tensor = prosody[0].repeat(target_len)
            else:
                prosody_tensor = prosody
            
            prosody_sequences.append(prosody_tensor)
        
        # Pad prosody sequences
        if prosody_sequences:
            max_prosody_len = max(len(seq) for seq in prosody_sequences)
            prosody_labels = torch.zeros(len(features), max_prosody_len, dtype=torch.float32)
            for i, seq in enumerate(prosody_sequences):
                prosody_labels[i, :len(seq)] = seq
        else:
            prosody_labels = torch.zeros(len(features), 1, dtype=torch.float32)
        
        return prosody_labels


class MTLDataset(Dataset):
    """
    Memory-efficient dataset following paper's approach with optimizations
    """
    
    def __init__(
        self,
        data_list: List[Dict],
        config,
        feature_extractor: Union[AutoProcessor, AutoFeatureExtractor],
        emotion_label_map: Optional[Dict[str, int]] = None,
        max_audio_length: int = 480000,  # ~30 seconds at 16kHz
    ):
        self.data_list = data_list
        self.config = config
        self.feature_extractor = feature_extractor
        self.max_audio_length = max_audio_length
        
        # Default emotion mapping
        if emotion_label_map is None:
            self.emotion_label_map = {
                'Neutral': 0, 'Confusion': 1, 'Anger': 2, 'Disgust': 3,
                'Frustration': 4, 'Sadness': 5, 'Surprise': 6, 'Joy': 7, 'Fear': 8
            }
        else:
            self.emotion_label_map = emotion_label_map
        
        # Filter data by audio length to prevent OOM
        self._filter_by_length()
        
        print(f"Created memory-efficient dataset with {len(self.data_list)} samples")

    def _filter_by_length(self):
        """Filter out samples that are too long to prevent OOM"""
        original_len = len(self.data_list)
        self.data_list = [
            item for item in self.data_list 
            if len(item.get('audio_data', [])) <= self.max_audio_length
        ]
        filtered_count = original_len - len(self.data_list)
        if filtered_count > 0:
            print(f"Filtered out {filtered_count} samples longer than {self.max_audio_length/16000:.1f}s")

    def __len__(self) -> int:
        return len(self.data_list)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        """Get sample with memory optimizations"""
        item = self.data_list[idx]
        
        # Get preprocessed audio data
        speech = item['audio_data']
        sr = item.get('audio_sr', 16000)
        
        # Ensure speech is numpy array with proper dtype
        if not isinstance(speech, np.ndarray):
            speech = np.array(speech, dtype=np.float32)
        else:
            # Ensure it's float32 (not float64 which uses more memory)
            speech = speech.astype(np.float32, copy=False)
        
        # Truncate if too long (additional safety)
        if len(speech) > self.max_audio_length:
            speech = speech[:self.max_audio_length]
        
        # Process through feature extractor with memory optimization
        features = self._extract_features_efficiently(speech, sr)
        
        # Get labels
        emotion = item['emotion']
        words = item.get('words', [])
        prosody = item.get('prosody_annotations', [])
        
        # Clean up to save memory
        del speech
        gc.collect()
        
        return {
            'input_features': features,
            'asr_target': words,
            'emotion_targets': emotion,
            'prosody_targets': torch.tensor(prosody, dtype=torch.float32) if prosody else torch.tensor([0.0]),
            'words': words,
            'audio_duration': len(item['audio_data']) / sr
        }

    def _extract_features_efficiently(self, speech: np.ndarray, sr: int) -> torch.Tensor:
        """Extract features with memory optimization"""
        # Use the feature extractor efficiently
        try:
            if hasattr(self.feature_extractor, 'feature_extractor'):
                # For models with separate feature extractor
                features = self.feature_extractor.feature_extractor(
                    speech,
                    sampling_rate=sr,
                    return_tensors="pt"
                )
            else:
                # For models with unified processor
                features = self.feature_extractor(
                    speech,
                    sampling_rate=sr,
                    return_tensors="pt"
                )
            
            # Extract the appropriate feature type
            if "input_values" in features:
                input_features = features.input_values.squeeze(0)
            elif "input_features" in features:
                input_features = features.input_features.squeeze(0)
            else:
                raise ValueError("Unknown feature format")
            
            # Convert to half precision to save memory
            return input_features.half()
            
        except Exception as e:
            print(f"Error extracting features: {e}")
            # Fallback: return zero tensor with appropriate shape
            if self.config.backbone_name == "whisper":
                return torch.zeros(80, len(speech) // 160, dtype=torch.float16)
            else:
                return torch.zeros(len(speech), dtype=torch.float16)